﻿using AparatMachine.Clasess;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AparatMachine.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageAddDrinks.xaml
    /// </summary>
    public partial class PageAddDrinks : Page
    {
        private Drinks _currentDrinks = new Drinks();
        string imgLoc = "пусто";
        public PageAddDrinks(Drinks selectedDrinks)
        {
            InitializeComponent();
            if (selectedDrinks != null)
            {
                _currentDrinks = selectedDrinks;
            }
            DataContext = _currentDrinks;
        }

        private void BtnCancel_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageMachine());
        }

        private void BtnAddOrEdit_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder error = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentDrinks.Name)) error.AppendLine("Укажите название напитка");
            if (string.IsNullOrWhiteSpace(_currentDrinks.Cost.ToString())) error.AppendLine("Укажите цену напитка");
            if ((_currentDrinks.Cost) < 0)
            {
                error.AppendLine("Цена не должна быть меньше 0");
            }
            if (error.Length > 0)
            {
                MessageBox.Show(error.ToString());
                return;
            }
            if (_currentDrinks.IdDrinks == 0)
            {
                ClassFrame.db.Drinks.Add(_currentDrinks);
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        string filename = imgLoc.Substring(imgLoc.LastIndexOf('\\') + 1);
                        _currentDrinks.Image = String.Concat("/Photo/", filename);
                    }
                    if (imgLoc == "пусто") _currentDrinks.Image = null;

                    ClassFrame.db.SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageMachine());
                    MessageBox.Show("Новый напиток успешно добавлен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
            else
            {
                try
                {
                    if (imgLoc != null && imgLoc != "пусто")
                    {
                        byte[] img = null;
                        FileStream fs = new FileStream(imgLoc, FileMode.Open, FileAccess.Read);
                        BinaryReader br = new BinaryReader(fs);
                        img = br.ReadBytes((int)fs.Length);
                        _currentDrinks.Image = imgLoc;
                    }
                    if (imgLoc == "пусто") _currentDrinks.Image = null;

                    ClassFrame.db.SaveChanges();
                    ClassFrame.frmObj.Navigate(new PageMachine());
                    MessageBox.Show("Напиток успешно изменен!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
            }
        }

        private void ImageLoad_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                OpenFileDialog dlg = new OpenFileDialog
                {
                    Filter = "JPG Files (*.jpg)|*.jpg|PNG Files (*.png)|*.png|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*",
                    Title = "Выберите фото/изображение напитка"
                };
                if (dlg.ShowDialog() == true)
                {
                    imgLoc = dlg.FileName.ToString();
                    imageDrinks.Source = new BitmapImage(new Uri(imgLoc));
                    File1.Text = "Файл выбран";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
