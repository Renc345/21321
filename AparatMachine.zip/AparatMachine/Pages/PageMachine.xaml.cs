﻿using AparatMachine.Clasess;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace AparatMachine.Pages
{
    /// <summary>
    /// Логика взаимодействия для PageMachine.xaml
    /// </summary>
    public partial class PageMachine : Page
    {
        public PageMachine()
        {
            InitializeComponent();
            LviewMachine.ItemsSource = ClassFrame.db.Drinks.ToList();
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddDrinks(null));
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            var usersForRemoving = LviewMachine.SelectedItems.Cast<Drinks>().ToList();
            if (MessageBox.Show($"Удалить {usersForRemoving.Count()} напитки?",
                "Внимание", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)

                try
                {
                    ClassFrame.db.Drinks.RemoveRange(usersForRemoving);
                    ClassFrame.db.SaveChanges();
                    MessageBox.Show("Данные удалены");
                    LviewMachine.ItemsSource = ClassFrame.db.Drinks.ToList();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message.ToString());
                }
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            ClassFrame.frmObj.Navigate(new PageAddDrinks((Drinks)LviewMachine.SelectedItem));
        }
    }
}
